namespace Atividade_11._11___Sistema_Cursos_MVC.Models
{
    public class Tecnico : Curso
    {
        public Tecnico() { }

        public Tecnico(int idConstrutor, string nomeConstrutor, int horasConstrutor) :
        base(idConstrutor, nomeConstrutor, horasConstrutor) { }
        
        public override double CalcularPreco() => Horas * 20.0;
    }
}