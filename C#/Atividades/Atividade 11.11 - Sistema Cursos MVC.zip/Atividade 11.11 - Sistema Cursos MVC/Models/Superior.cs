namespace Atividade_11._11___Sistema_Cursos_MVC.Models
{
    public class Superior : Curso
    {
        public Superior() { }

        public Superior(int idConstrutor, string nomeConstrutor, int horasConstrutor) :
        base(idConstrutor, nomeConstrutor, horasConstrutor) { }
        
        public override double CalcularPreco() => Horas * 40.0;
    }
}