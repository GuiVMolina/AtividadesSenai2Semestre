using System.ComponentModel.DataAnnotations;

namespace Atividade_11._11___Sistema_Cursos_MVC.Models
{
    public abstract class Curso
    {
        [Key]
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
        public int Horas { get; set; }

        public Curso() { }

        public Curso(int idConstrutor, string nomeConstrutor, int horasConstrutor)
        {
            Id = idConstrutor;
            Nome = nomeConstrutor;
            Horas = horasConstrutor;
        }

        public abstract double CalcularPreco();
    }
}