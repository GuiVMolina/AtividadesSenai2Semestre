namespace SegregacaoInterfaces
{
    public interface ITrabalhador
    {
        void Trabalhar();
    }
}