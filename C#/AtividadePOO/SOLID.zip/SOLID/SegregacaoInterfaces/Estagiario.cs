namespace SegregacaoInterfaces
{
    public class Estagiario : ITrabalhador
    {
        public void Trabalhar() => Console.WriteLine("Estagiário trabalhando...");
    }
}