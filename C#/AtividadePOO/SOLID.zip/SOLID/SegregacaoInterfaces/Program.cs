﻿namespace SegregacaoInterfaces;

class Program
{
    static void Main(string[] args)
    {
        Estagiario estagiario = new Estagiario();
        estagiario.Trabalhar();
    }
}
