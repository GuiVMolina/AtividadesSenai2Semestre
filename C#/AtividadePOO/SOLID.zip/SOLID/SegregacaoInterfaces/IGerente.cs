namespace SegregacaoInterfaces
{
    public interface IGerente
    {
        void PlanejarReuniao();
    }
}