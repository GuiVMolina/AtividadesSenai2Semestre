namespace AbertoFechado
{
    public abstract class Desconto
    {
        public abstract double Calcular(double valor);
    }
}